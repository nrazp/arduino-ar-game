---
title: open-new-external-code
---

Double-click the new C# file. Unity opens the file in the program you specified in your preferences, under **External Script Editor**. 

> [!NOTE]
> For more information on script editors in Unity, see the [Integrated development environment (IDE) support](https://docs.unity3d.com/Manual/ScriptingToolsIDEs.html) in the Unity User Manual.
