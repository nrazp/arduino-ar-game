---
title: nodes-input-system-output-trigger-port
---
<tr>
<td><strong>Trigger</strong></td>
<td>Output Trigger</td>
<td>The control output port. Make a connection to specify what Visual Scripting does after the configured Player Input event, such as a button press, occurs in the application.</td>
</tr>
