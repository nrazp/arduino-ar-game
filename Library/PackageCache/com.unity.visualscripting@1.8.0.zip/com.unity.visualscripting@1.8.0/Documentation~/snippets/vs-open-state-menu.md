---
title: open-state-menu
---

With a State Graph [open in the Graph window](../vs-open-graph-edit.md), right-click on an empty space in the Graph Editor to open the context menu.
