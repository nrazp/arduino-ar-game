---
title: visual-scripting-window
---

 Go to **Window** &gt; **Visual Scripting** &gt; **Visual Scripting Graph**. 