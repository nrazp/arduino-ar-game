namespace Unity.VisualScripting
{
    public interface IAnalysis
    {
    }
}
