namespace Unity.VisualScripting
{
    public enum CanvasControlScheme
    {
        [RenamedFrom("Unity")]
        Default,
        [RenamedFrom("Unreal")]
        Alternate
    }
}
