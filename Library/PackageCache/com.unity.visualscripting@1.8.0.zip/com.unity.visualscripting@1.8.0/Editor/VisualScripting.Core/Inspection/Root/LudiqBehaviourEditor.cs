using UnityEditor;

namespace Unity.VisualScripting
{
    [CustomEditor(typeof(LudiqBehaviour), true)]
    public class LudiqBehaviourEditor : LudiqRootObjectEditor { }
}
