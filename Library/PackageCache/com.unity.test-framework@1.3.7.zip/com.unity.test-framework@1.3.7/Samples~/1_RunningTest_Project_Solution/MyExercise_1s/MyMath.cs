
namespace MyExercise_1s
{
    public static class MyMath
    {
        public static int Add(int a, int b)
        {
            return a + b;
        }
    
        public static int Subtract(int a, int b)
        {
            return a - b; // Fixed
        }
    }
}
