using NUnit.Framework;

namespace Tests_3
{
    internal class ValueOutputterTests
    {
        [Test]
        public void YourTestGoesHere()
        {
            
        }
    }
}