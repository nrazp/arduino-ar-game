﻿using System.Collections;
using NUnit.Framework;
using UnityEngine.TestTools;

namespace Tests_15
{
    public class MyClassTests
    {
        [Test]
        public void YourTestGoesHere()
        {
            Assert.Fail();
        }
    }
}
