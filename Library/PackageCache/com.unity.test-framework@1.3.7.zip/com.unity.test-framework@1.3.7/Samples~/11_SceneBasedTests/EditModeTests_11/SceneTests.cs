﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.TestTools;

namespace EditModeTests_11
{
    public class SceneTests
    {
        [Test]
        public void YourTestGoesHere()
        {
            
        }
    }
}
