using NUnit.Framework;

namespace Tests_4
{
    internal class ValueOutputterTests
    {
        [Test]
        public void YourTestGoesHere()
        {
            
        }
    }
}