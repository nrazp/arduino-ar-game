using NUnit.Framework;

namespace Tests_5
{
    internal class MyLoggingClassTests
    {
        [Test]
        public void YourTestGoesHere()
        {
            
        }
    }
}