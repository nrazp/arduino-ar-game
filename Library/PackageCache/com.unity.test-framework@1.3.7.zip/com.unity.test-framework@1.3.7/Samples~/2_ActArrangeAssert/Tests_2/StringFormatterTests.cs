using NUnit.Framework;

namespace Tests_2
{
    internal class StringFormatterTests
    {
        [Test]
        public void YourTestGoesHere()
        {
            
        }
    }
}