using NUnit.Framework;

namespace Tests_6
{
    internal class FileCreatorTests
    {
        [Test]
        public void YourTestGoesHere()
        {
            
        }
    }
}