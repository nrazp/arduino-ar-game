namespace UnityEngine.TestTools
{
    internal class IgnoreTest
    {
        public string test { get; set; }
        public string ignoreComment { get; set; }
    }
}
