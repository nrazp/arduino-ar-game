using System;

namespace UnityEditor.TestTools.TestRunner.TestRun
{
    internal enum TaskMode
    {
        Normal,
        Error,
        Resume,
        EnteredEditMode,
        Canceled,
    }
}
