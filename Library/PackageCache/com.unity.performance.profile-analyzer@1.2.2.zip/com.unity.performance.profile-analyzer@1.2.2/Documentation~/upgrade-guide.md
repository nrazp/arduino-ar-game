# Profile Analyzer upgrade guide

You do not need to take any actions to upgrade your project when you update this package.
