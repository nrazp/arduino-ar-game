# Custom Nunit build to work with Unity

This version of nunit works with all platforms, il2cpp and Mono AOT.

For Nunit Documentation:
https://github.com/nunit/docs/wiki/NUnit-Documentation

This source code for this packages lives at https://github.com/Unity-Technologies/nunit

This custom Nunit is based on Nunit version 3.5, and it is precompiled for .NET 4.0. The uncompiled public version lives here https://github.com/Unity-Technologies/nunit.
