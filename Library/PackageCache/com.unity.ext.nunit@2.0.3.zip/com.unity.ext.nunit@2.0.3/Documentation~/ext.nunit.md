# Custom Nunit manual

## Package Summary
A custom version of NUnit used by Unity Test Framework. Based on NUnit version 3.5 and works with all platforms, il2cpp and Mono AOT. 

See the [NUnit documentation](https://docs.nunit.org/) for more information.

