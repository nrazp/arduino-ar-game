namespace UnityEditor.TestTools.CodeCoverage
{
    internal enum CoverageFormat
    {
        OpenCover = 0,
        DotCover = 1
    }
}
