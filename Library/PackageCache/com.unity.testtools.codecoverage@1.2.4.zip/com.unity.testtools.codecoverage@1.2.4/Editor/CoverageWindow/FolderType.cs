﻿namespace UnityEditor.TestTools.CodeCoverage
{
    internal enum FolderType
    {
        Results = 0,
        History = 1
    }
}
